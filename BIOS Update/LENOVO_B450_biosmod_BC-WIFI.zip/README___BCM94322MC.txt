Use this modded BIOS for Lenovo B450 Laptop only if you have the same card:
PCI\VEN_14E4&DEV_432B&SUBSYS_137F103C